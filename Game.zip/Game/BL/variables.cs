﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game.Variables
{
    class variables
    {
        public int option = 0;
        public int x = 15;
        public int y = 15;
        public int n = 5;
    }
}
