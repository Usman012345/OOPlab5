﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_task2.Class
{
    class variables
    {
        public bool found = false;
        public int option;
        public string mname;
        public string line;
        public char comma = ',';
        
    }
}
