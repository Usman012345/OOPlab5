﻿using System;
using Project_task2.Class;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_task2.medicine
{
    class medicine__info
    {
       public static List<medicine__info> med = new List<medicine__info>();
        public int price;
        public string medicine;
        public medicine__info(int price,string medicine)
        {
            this.price = price;
            this.medicine = medicine;
        }
        
    }

}
