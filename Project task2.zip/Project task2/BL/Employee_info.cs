﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_task1.Employee
{

    class Employee_info
    {
       public string employee_name,role;
        public int pay;
        public static List<Employee_info> employees = new List<Employee_info>();
        public Employee_info(string employee_name,string role,int pay)
        {
            this.employee_name = employee_name;
            this.role = role;
            this.pay = pay;
        }

    }
}
