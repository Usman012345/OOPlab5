﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_task1.UI
{
    class wrong_input
    {
        public static void wrong_input_()
        {
            Console.WriteLine("Wrong input!!!");
            Console.ReadLine();

        }     
    }
}
