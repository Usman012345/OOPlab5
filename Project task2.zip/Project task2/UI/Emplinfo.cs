﻿using System;
using System.Collections.Generic;
using System.Linq;
using Project_task1.Employee;
using System.Text;
using Project_task2.Class;
using System.Threading.Tasks;

namespace Project_task1.UI
{
    class Emplinfo
    {
        public static void Emplinfo_(ref string name,ref string role, ref int pay)
        {
            Console.WriteLine("Enter the employee name: ");
            name = Console.ReadLine();
            Console.WriteLine("Enter the role");
            role = Console.ReadLine();
            Console.WriteLine("Enter the pay");
            pay = int.Parse(Console.ReadLine());
        }
       public static void employee_record()
        {
            foreach (Employee_info data in Employee_info.employees)
            {
                Console.WriteLine("{0}    {1}    {2}", data.employee_name, data.role, data.pay);
            }
        }
        public static string enter_employee(bool option)
        {
            string ename="";
            variables v = new variables();
            Console.WriteLine("Main menu<<Sign in/up<<Admin menu<<Remove employee ");
            if (option == true)
            {
                Console.WriteLine("Enter employee name: ");
                ename = Console.ReadLine();

            }
            else
                Console.WriteLine("The employee does not exist.");
            return ename;
        }
    }
}
