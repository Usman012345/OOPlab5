﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_task1.UI
{
    class readkey
    {
        public static void readkey_()
        {
            Console.ReadKey();
        }
    }
}
