﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project_task1.DL;
using Project_task2.medicine;
using Project_task2.Class;

namespace Project_task1.UI
{
    class medinfo
    {

        public static void medinfo_(ref string medicine, ref int price)
        {
            Console.WriteLine("Main menu<<Sign in/up<<Admin menu<<Add medicine ");
            Console.WriteLine("Enter medicine name: ");
            medicine = Console.ReadLine();
            Console.WriteLine("Enter the price: ");
            price = int.Parse(Console.ReadLine());
        }
         public static void Print_medicine_record(variables v, List<medicine__info> med)
        {

            Console.WriteLine("Main menu<<Sign in/up<<Admin menu<<Print medicine record ");
            for (int x = 0; x < med.Count; x++)
            {
                Console.WriteLine("{0} , Price: {1}", med[x].medicine, med[x].price);
            }
        }
        public static string enter_medicine(bool option)
        {
            variables v = new variables();
            Console.WriteLine("Main menu<<Sign in/up<<Admin menu<<Remove medicine ");
            if (option == true)
            {
                Console.WriteLine("Enter medicine name: ");
                v.mname = Console.ReadLine();

            }
            else
                Console.WriteLine("The medicine does not exist.");
            return v.mname;
        }
    }
}
