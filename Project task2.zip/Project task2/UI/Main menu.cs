﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project_task2.Class;

namespace Project_task1.UI
{
    class Main_menu
    {
        public static void main_menu_()
        {
            variables v = new variables();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(" ### ##   ###  ##    ##     ### ##  ##   ##     ##      ## ##  ##  ##             ### ##   ### ###   ## ##    ## ##   ### ##   ### ##");
            Console.WriteLine(" ##  ##   ##  ##     ##     ##  ##   ## ##      ##    ##   ##  ##  ##             ##  ##   ##  ##  ##   ##  ##   ##   ##  ##   ##  ##");
            Console.WriteLine(" ##  ##   ##  ##   ## ##    ##  ##  # ### #   ## ##   ##       ##  ##             ##  ##   ##      ##       ##   ##   ##  ##   ##  ##");
            Console.WriteLine(" ##  ##   ## ###   ##  ##   ## ##   ## # ##   ##  ##  ##        ## ##             ## ##    ## ##   ##       ##   ##   ## ##    ##  ##");
            Console.WriteLine(" ## ##    ##  ##   ## ###   ## ##   ##   ##   ## ###  ##         ##               ## ##    ##      ##       ##   ##   ## ##    ##  ##");
            Console.WriteLine(" ##       ##  ##   ##  ##   ##  ##  ##   ##   ##  ##  ##   ##    ##               ##  ##   ##  ##  ##   ##  ##   ##   ##  ##   ##  ##");
            Console.WriteLine("####     ###  ##  ###  ##  #### ##  ##   ##  ###  ##   ## ##     ##              #### ##  ### ###   ## ##    ## ##   #### ##  ### ## ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Main menu<<Sign in/up<<Admin menu");
            Console.WriteLine("1.Add medicine record..");
            Console.WriteLine("2.Print medicine record..");
            Console.WriteLine("3.Remove medicine..");
            Console.WriteLine("4.Add Employee..");
            Console.WriteLine("5.Print employee record");
            Console.WriteLine("6.Remove employee");
            Console.WriteLine("0.exit");
            v.option = int.Parse(Console.ReadLine());
        }
    }
}
