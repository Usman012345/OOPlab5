﻿using System.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project_task2.Class;
using Project_task2.medicine;
using Project_task1.UI;
using Project_task1.Employee;
using Project_task1.DL;
namespace Project_task1
{
    class Program
    {
        static int Main(string[] args)
        {

            
            
            /*medicine__info m = new medicine__info();*/
            variables v = new variables();
          Medfile.readfile(v, medicine__info.med);
        jump:
            while (true)
            {
                Main_menu.main_menu_();
                
                if (v.option == 1)
                {
                    medicine__info. med.Add( medicine_info(v));
                   Medfile.storedata(medicine__info.med);
                   
                }
                if (v.option == 2)
                {
                   medinfo. Print_medicine_record(v, medicine__info.med);
                   
                }   
                if (v.option == 3)
                {
                    Remove_medicine(v, medicine__info.med);
                   
                }
                if(v.option==4)
                {
                   Employee_info.employees.Add( Add_employee());
                }
                if(v.option==5)
                {
                   Emplinfo.employee_record();
                }
                if(v.option==6)
                {
                    remove_employee();
                }
                if (v.option == 0)
                {

                    return 0;
                }
                else if (new[] { 1, 2, 3, 4,5,6,7,0 }.All(x => x != v.option))
                {
                    wrong_input.wrong_input_();
                    goto jump;
                }
                readkey.readkey_();
            }
            return 0;


        }
        static public medicine__info medicine_info(variables v)
        {
            string medicine="";
            int price=0;
            medinfo.medinfo_(ref medicine, ref price);
            medicine__info m = new medicine__info(price, medicine);
            return m;
        }
        static public void Remove_medicine(variables v, List<medicine__info> med)
        {
            string name;
           name= medinfo.enter_medicine(true);
            for (int x = 0; x < med.Count; x++)
            {
                if (name == med[x].medicine)
                {
                    v.found = true;
                    med.RemoveAt(x);
                }
            }
            if (v.found == false)
                medinfo.enter_medicine(false);
        }
        static Employee_info Add_employee()
        {
            string name="",role="";
            int pay=0;
            Emplinfo.Emplinfo_(ref name, ref role, ref pay);
            Employee_info e = new Employee_info(name,role,pay);
            return e;
        }
        
        static void remove_employee()
        {
            string name;
            name=Emplinfo.enter_employee(true);
            for(int x=0;x<Employee_info.employees.Count;x++)
            {
                if(name==Employee_info.employees[x].employee_name)
                {
                    Employee_info.employees.RemoveAt(x);
                }
            }
        }
    }
}
