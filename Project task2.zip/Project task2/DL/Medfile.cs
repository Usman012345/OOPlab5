﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project_task2.medicine;
using Project_task2.Class;
using System.IO;
namespace Project_task1.DL
{
    class Medfile
    {
        public static void readfile(variables v, List<medicine__info> med)
        {
            string medicine;
            int price;
            if (File.Exists("E:\\PD\\PDlab2\\Project task2\\medicine_data.txt"))
            {

                StreamReader data = new StreamReader("E:\\PD\\PDlab2\\Project task2\\medicine_data.txt", true);
                while ((v.line = data.ReadLine()) != null)
                {
                    // v.line = data.ReadLine();
                    string[] line1 = v.line.Split(',');
                    medicine = line1[0];
                    price = int.Parse(line1[1]);
                    medicine__info m = new medicine__info(price, medicine);
                    med.Add(m);
                }
                data.Close();
            }
        }
        public static void storedata(List<medicine__info> med)
        {
            if (File.Exists("E:\\PD\\PDlab2\\Project task2\\medicine_data.txt"))
            {
                StreamWriter data = new StreamWriter("E:\\PD\\PDlab2\\Project task2\\medicine_data.txt", true);
                for (int x = 0; x < med.Count; x++)
                    data.WriteLine("{0},{1}", med[x].medicine, med[x].price);
                data.Flush();
                data.Close();
            }
        }
    }
}
